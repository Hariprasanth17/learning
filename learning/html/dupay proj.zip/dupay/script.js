document.addEventListener("DOMContentLoaded", function() {
    const iconImage = document.querySelector('.icon-image img');
    const navbarList = document.querySelector('.main-navbar');
    
    iconImage.addEventListener("click", function() {
        navbarList.classList.toggle("show-navbar");
    });

    document.querySelectorAll('.navbar-list a').forEach(anchor => {
        anchor.addEventListener("click", function(event) {
            event.preventDefault();
            const sectionId = this.getAttribute("href");
            document.querySelector(sectionId).scrollIntoView({
                behavior: "smooth"
            });
        });
    });

    const button = document.querySelector('.navbar-list button');
    button.addEventListener("click", function() {
        alert("Button clicked! This can be customized to link to a form or another page.");
    });

    const qrCode = document.querySelector('.qrcode');
    qrCode.addEventListener("mouseenter", function() {
        qrCode.style.borderColor = "#03DEFF";
    });
    qrCode.addEventListener("mouseleave", function() {
        qrCode.style.borderColor = "white";
    });
});
