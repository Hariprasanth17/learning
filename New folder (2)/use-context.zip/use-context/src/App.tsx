

import './App.css'
import ComponentA from './Component/CoponentA/ComponentA'

function App() {


  return (
    <>
      <ComponentA />
    </>
  )
}

export default App
